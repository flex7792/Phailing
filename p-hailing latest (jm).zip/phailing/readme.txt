Configure the database connection:
  - Open the "config.php" file.
  - Update the database connection settings (servername, username, password, dbname) with your MySQL credentials.
  - Database named "p-hailing". 

Start the application:
  - Ensure your local server XAMPP is running. Start the first two.
  - Place the "p-hailing" folder in the "htdocs" directory.
  - Open a web browser and navigate to the application's directory (e.g., http://localhost/p-hailing/index.php).


